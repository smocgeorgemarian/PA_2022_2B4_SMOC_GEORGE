create PROCEDURE writeInFiles AS

-- vars decl
  v_counter INTEGER := 0;
  v_file UTL_FILE.FILE_TYPE;
BEGIN
    v_file := UTL_FILE.FOPEN('MYDIR','export.sql','W');

    FOR v_line in  (SELECT s.text, s.line FROM user_objects o  
        JOIN user_source s ON o.object_type IN ('FUNCTION', 'PROCEDURE') AND o.object_name = s.name AND o.object_type = s.type 
        ORDER BY o.created, s.line) LOOP
        v_counter := v_counter + 1;
        IF v_line.line = 1 AND v_counter > 1 THEN
            UTL_FILE.NEW_LINE(v_file);
            UTL_FILE.PUTF(v_file, '/');
            UTL_FILE.NEW_LINE(v_file);
        END IF; 
        UTL_FILE.PUTF(v_file, v_line.text);
    END LOOP;
    UTL_FILE.FCLOSE(v_file);
END writeInFiles;
/

