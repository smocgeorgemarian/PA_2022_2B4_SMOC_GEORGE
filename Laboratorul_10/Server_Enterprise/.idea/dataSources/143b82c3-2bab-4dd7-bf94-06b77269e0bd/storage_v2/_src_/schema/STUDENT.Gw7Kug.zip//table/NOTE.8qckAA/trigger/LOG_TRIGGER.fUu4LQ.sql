create trigger LOG_TRIGGER
    before insert or update or delete
    on NOTE
    for each row
DECLARE
    v_op_type VARCHAR2(255);
    v_user VARCHAR2(255);
    v_id NUMBER;
BEGIN
    SELECT user INTO v_user FROM DUAL;
    CASE
    WHEN INSERTING 
    THEN 
        v_op_type := 'INSERT'; 
        v_id := :NEW.id;
    WHEN UPDATING 
    THEN 
        v_op_type := 'UPDATE';
        v_id := :NEW.id;
    WHEN DELETING 
    THEN 
        v_op_type := 'DELETE';
        v_id := :OLD.id;
    END CASE;
    insert into logs values (v_id, :OLD.valoare, :NEW.valoare, v_op_type, CURRENT_TIMESTAMP, v_user);	
    -- code
END;
/

