create trigger DML_MUTATION1
    instead of update
    on STUDENTI
    for each row
    COMPOUND TRIGGER
    v_nume studenti.nume%type;
    before statement IS
    BEGIN
        select nume into v_nume from studenti where id = 1;
    END before statement;
    before each row IS
    BEGIN
            dbms_output.put_line('TEST');
    END before each row;

END dml_mutation1;
/

