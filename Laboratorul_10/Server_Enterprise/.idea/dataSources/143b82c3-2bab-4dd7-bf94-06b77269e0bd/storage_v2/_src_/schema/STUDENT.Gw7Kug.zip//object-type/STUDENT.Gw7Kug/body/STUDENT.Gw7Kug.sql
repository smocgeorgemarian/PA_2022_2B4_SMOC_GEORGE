create TYPE BODY student AS
   MEMBER PROCEDURE afiseaza_foaie_matricola IS
   BEGIN
       DBMS_OUTPUT.PUT_LINE('Aceasta procedura calculeaza si afiseaza foaia matricola');
   END afiseaza_foaie_matricola;
END;
/

