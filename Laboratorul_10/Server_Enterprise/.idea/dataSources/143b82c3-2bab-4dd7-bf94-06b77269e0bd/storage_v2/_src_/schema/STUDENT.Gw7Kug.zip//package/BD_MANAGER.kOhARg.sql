create PACKAGE bd_manager AS
-- public vars_decl
-- public func_decl
    PROCEDURE get_source_code (p_name VARCHAR2);
    FUNCTION get_function_name RETURN VARCHAR2;
END;
/

