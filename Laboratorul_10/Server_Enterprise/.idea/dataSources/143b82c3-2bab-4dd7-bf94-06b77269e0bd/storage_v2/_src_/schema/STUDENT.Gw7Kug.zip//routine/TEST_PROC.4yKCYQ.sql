create PROCEDURE test_proc (p_val IN OUT NUMBER) AS
-- vars decl
BEGIN
    dbms_output.put_line(p_val);
END test_proc;
/

