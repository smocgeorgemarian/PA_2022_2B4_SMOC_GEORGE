create PROCEDURE export_lines (p_val IN VARCHAR2) AS
-- vars decl
v_file UTL_FILE.FILE_TYPE;
v_drop_cmd VARCHAR2(200);
v_create_cmd VARCHAR2(200);

BEGIN
    v_file := UTL_FILE.FOPEN('MYDIR','export_lines.sql','W');
    v_drop_cmd := 'DROP TABLE ' || p_val || ';';
--    drop cmd
    UTL_FILE.PUTF(v_file, v_drop_cmd);
    UTL_FILE.NEW_LINE(v_file);
    UTL_FILE.PUTF(v_file, '/');
    UTL_FILE.NEW_LINE(v_file);

    UTL_FILE.FCLOSE(v_file);
END export_lines;
/

