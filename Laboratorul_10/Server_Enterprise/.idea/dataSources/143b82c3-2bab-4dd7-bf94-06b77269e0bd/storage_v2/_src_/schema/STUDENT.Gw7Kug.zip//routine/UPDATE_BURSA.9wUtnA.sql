create PROCEDURE update_bursa (p_id IN INTEGER) AS
    v_bursa NUMBER;
    v_nume studenti.nume%type;
    v_counter INTEGER;
BEGIN
    SELECT COUNT(*) INTO V_counter FROM studenti WHERE id = p_id;

    IF (v_counter = 0) THEN
        raise exceptions_bursa.no_id_found;
    END IF;
    SELECT nume, bursa into v_nume, v_bursa from STUDENTI where id = p_id;
    IF (v_bursa IS NULL) THEN
        raise exceptions_bursa.no_bursa_found;
    END IF;
    dbms_output.put_line('Bursa inainte update este: ' || v_bursa);
    UPDATE studenti SET BURSA = v_bursa + 10 where id = p_id;
    SELECT BURSA into v_bursa from studenti where id = p_id;
    dbms_output.put_line('Bursa dupa update este: ' || v_bursa);
END update_bursa;
/

