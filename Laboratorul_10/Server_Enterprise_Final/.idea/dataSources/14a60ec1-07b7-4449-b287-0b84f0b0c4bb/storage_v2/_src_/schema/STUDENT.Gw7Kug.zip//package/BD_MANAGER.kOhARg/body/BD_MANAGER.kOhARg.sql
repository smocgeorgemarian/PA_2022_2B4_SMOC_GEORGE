create PACKAGE BODY bd_manager AS
-- private vars decl
-- proc/func implement
    PROCEDURE get_source_code (p_name VARCHAR2) AS
    v_code VARCHAR2(1000) := '';
    BEGIN
        FOR v_line in (select * from USER_SOURCE where lower(name) = lower(p_name)) LOOP
            v_code := CONCAT (v_code /*CHAR1*/,
                            v_line.text /*CHAR2*/);
        END LOOP;
        dbms_output.put_line('The lines of code for ' || p_name || ':');
        dbms_output.put_line(v_code);
    END;

    FUNCTION get_function_name RETURN VARCHAR2 AS
        v_maxim INTEGER := -1;
        v_value INTEGER;
        v_maxim_name VARCHAR2(100) := 'Object not found';
    BEGIN
        FOR v_line in (select * from user_objects WHERE LOWER(object_type) in ('procedure', 'function')) LOOP

            SELECT count(*) into v_value from USER_SOURCE where name = v_line.object_name;

            IF (v_value > v_maxim) THEN
                dbms_output.put_line('Max value: ' || v_value);
                v_maxim := v_value;
                v_maxim_name := v_line.object_name;
            ELSIF (v_value = v_maxim) THEN
                dbms_output.put_line('Max value tie: ' || v_value);
                v_maxim_name := CONCAT(v_maxim_name, CONCAT(', ', v_line.object_name));
            END IF;
        END LOOP;
        return v_maxim_name;
    END;
BEGIN  null;
END bd_manager;
/

