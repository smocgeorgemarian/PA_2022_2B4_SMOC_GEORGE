create PACKAGE exceptions_bursa IS
-- public vars_decl
-- public func_decl
    no_bursa_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_bursa_found, -20001);

    no_id_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_id_found, -20002);

END exceptions_bursa;
/

