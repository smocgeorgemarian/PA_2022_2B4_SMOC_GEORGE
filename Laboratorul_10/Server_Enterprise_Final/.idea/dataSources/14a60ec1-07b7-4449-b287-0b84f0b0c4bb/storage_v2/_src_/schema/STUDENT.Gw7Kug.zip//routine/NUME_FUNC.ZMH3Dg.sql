create FUNCTION nume_func(p_string VARCHAR2)
RETURN INT AS
BEGIN
    return 1;
END;
/

