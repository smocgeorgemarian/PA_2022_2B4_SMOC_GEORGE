create PROCEDURE export_file (p_val IN VARCHAR) AS
-- vars decl
    v_file UTL_FILE.FILE_TYPE;
    v_drop_cmd VARCHAR2(300) := 'DROP TABLE' || ' ' || UPPER(p_val) || ';\n/\n';
    v_statement VARCHAR2(300) := 'SELECT * FROM ' || UPPER(p_val);
    v_create_cmd VARCHAR2(300) := 'CREATE TABLE ' || UPPER(p_val) || ' (';

    v_cursor_id NUMBER;
    v_ok        NUMBER;
    v_rec_tab     DBMS_SQL.DESC_TAB;
    v_nr_col     NUMBER;
    v_total_coloane     NUMBER; 
    v_counter NUMBER := 0;
    v_col_name VARCHAR2(300);
    v_index NUMBER;
    v_cursor NUMBER;

BEGIN
    v_file := UTL_FILE.FOPEN('MYDIR','export.sql','W');
    -- drop cmd
    UTL_FILE.PUTF(v_file, v_drop_cmd);
    -- create cmd
    v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(v_cursor_id , v_statement, DBMS_SQL.NATIVE);

    v_cursor := dbms_sql.open_cursor;
    dbms_sql.PARSE(v_cursor, v_statement, DBMS_SQL.native);

    v_ok := DBMS_SQL.EXECUTE(v_cursor_id);
    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);

    v_nr_col := v_rec_tab.first;

    IF (v_nr_col IS NOT NULL) THEN
    LOOP
      v_counter := v_counter + 1;
      IF (v_counter != 1) THEN
        v_create_cmd := v_create_cmd || ',';
      END IF;
      v_col_name := UPPER(v_rec_tab(v_nr_col).col_name);
      dbms_sql.define_column(v_cursor, v_counter, v_col_name, 2000);

      v_create_cmd := v_create_cmd || '\n' || v_col_name || ' ' || gettype(v_rec_tab,v_nr_col);
      v_nr_col := v_rec_tab.next(v_nr_col);
      EXIT WHEN (v_nr_col IS NULL);
    END LOOP;
    END IF;
    DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
    v_create_cmd := v_create_cmd || '\n);\n/\n';
    UTL_FILE.PUTF(v_file, v_create_cmd);
    --insert
    v_cursor_id := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(v_cursor_id, v_statement, DBMS_SQL.NATIVE);
    v_ok := DBMS_SQL.EXECUTE(v_cursor_id);

--    LOOP 
--        IF DBMS_SQL.FETCH_ROWS(v_cursor_id)>0 THEN 
--            dbms_output.put_line(DBMS_SQL.COLUMN_VALUE(v_cursor_id, 1, 2000));  
--        ELSE 
--            EXIT; 
--        END IF; 
--    END LOOP;
--    DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
    --end insert
    UTL_FILE.FCLOSE(v_file);
END export_file;
--============================================================================
/

