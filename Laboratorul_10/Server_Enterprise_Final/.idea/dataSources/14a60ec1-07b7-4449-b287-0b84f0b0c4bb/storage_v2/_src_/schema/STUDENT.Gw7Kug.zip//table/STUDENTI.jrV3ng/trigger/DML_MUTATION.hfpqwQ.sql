create trigger DML_MUTATION
    before insert or update or delete
    on STUDENTI
    for each row
DECLARE
    v_nume studenti.nume%type;

BEGIN
    select nume into v_nume from studenti where id = 1;

END;



CREATE OR REPLACE TRIGGER dml_mutation1
    FOR UPDATE ON studenti
COMPOUND TRIGGER
    v_nume studenti.nume%type;
    before statement IS
    BEGIN
        select nume into v_nume from studenti where id = 1;
    END;
    before each row IS
    BEGIN
            dbms_output.put_line('TEST');
    END;

END dml_mutation1;
/

